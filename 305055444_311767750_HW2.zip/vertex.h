#pragma once
class vertex
{
public:
	vertex(){
		x = 0;
		y = 0;
		z = 0;
		p = 0;
	};
	~vertex();

	double x;
	double y;
	double z;
	double p;
};

